﻿using MySql.Data.MySqlClient;
using StoloviePribiory.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StoloviePribiory.Classes
{
    class MySQLDataProvider: IDataPrivider
    {
        private MySqlConnection Connection;
        public MySQLDataProvider()
        {
            try
            {
                Connection = new MySqlConnection(
                    "Server=server232;Database=exam1;port=3306;UserId=serv232;password=123456;");
            }
            catch (Exception)
            {
            }
        }

    
        public IEnumerable<Product> GetProducts()
        {
            List<Product> ProductList = new List<Product>();
            string Query = @"SELECT * From Product";

            try
            {
                // открываем соединение с сервером
                Connection.Open();
                try
                {
                    // создаем команду
                    MySqlCommand Command = new MySqlCommand(Query, Connection);
                    // получаем результат команды (массив строк)
                    MySqlDataReader Reader = Command.ExecuteReader();

                    // перебираем стоки
                    while (Reader.Read())
                    {
                        // создаем экземпляр класса 
                        Product NewProduct = new Product();
                        // и заполняем его поля
                        NewProduct.ProductArticleNumber = Reader.GetString("ProductArticleNumber");
                        NewProduct.ProductName = Reader.GetString("ProductName");
                        NewProduct.ProductDescription = Reader.GetString("ProductDescription");
                        NewProduct.ProductCategory = Reader.GetString("ProductCategory");
                        NewProduct.ProductPhoto = Reader.GetString("ProductPhoto");
                        NewProduct.ProductManufacturer = Reader.GetString("ProductManufacturer");
                        NewProduct.ProductCost = Reader.GetInt32("ProductCost");
                        NewProduct.ProductDiscountAmount = Reader.GetInt32("ProductDiscountAmount");
                        NewProduct.ProductQuantityInStock = Reader.GetInt32("ProductQuantityInStock");
                        NewProduct.ManufacturerID = Reader.GetInt32("ManufacturerID");
                        ProductList.Add(NewProduct);

                        // Методы Get<T> не поддерживают работу с NULL
                        // для полей, в которых может встретиться NULL (а лучше для всех)
                        // используйте следующий синтаксис


                        // добавляем экземпляр класса в список продуктов
                        ProductList.Add(NewProduct);
                    }
                }
                finally
                {
                    // обязательно закрываем соединение
                    // ресурсы сервера конечны
                    Connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return ProductList;
        }
        public IEnumerable<Manufactyre> GetManufactyres()
        {
            List<Manufactyre> productTypeList = new List<Manufactyre>();
            string Query = "SELECT * FROM Manufactyrer";

            try
            {
                Connection.Open();
                try
                {
                    MySqlCommand Command = new MySqlCommand(Query, Connection);
                    MySqlDataReader Reader = Command.ExecuteReader();

                    while (Reader.Read())
                    {
                        Manufactyre NewManufactyre = new Manufactyre();
                        NewManufactyre.ID = Reader.GetInt32("ID");
                        NewManufactyre.Title = Reader.GetString("Title");

                        productTypeList.Add(NewManufactyre);
                    }
                }
                finally
                {
                    Connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return productTypeList;

        }
    }
}
