﻿using StoloviePribiory.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoloviePribiory.Classes
{
    interface IDataPrivider
    {
        IEnumerable<Product> GetProducts();
        IEnumerable<Manufactyre> GetManufactyres();
    }
}
