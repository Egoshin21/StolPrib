﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoloviePribiory
{
    public class Product
    {
        public string ProductArticleNumber { get; set; }

        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public string ProductCategory { get; set; }
        public string ProductPhoto { get; set; }
        public string ProductManufacturer { get; set; }
        public int ProductCost { get; set; }
        public int ProductDiscountAmount { get; set; }
        public int ProductQuantityInStock { get; set; }
        public int ManufacturerID { get; set; }
        public Uri ImagePreview
        {
            get
            {
                var imageName = Environment.CurrentDirectory + (ProductPhoto ?? "");
                return System.IO.File.Exists(imageName) ? new Uri(imageName) : null;
            }
        }

    }
}
