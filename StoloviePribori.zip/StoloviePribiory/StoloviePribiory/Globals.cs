﻿using StoloviePribiory.Classes;
using StoloviePribiory.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoloviePribiory
{
    class Globals
    {
        public static IDataPrivider DataPrivider;
        public static IEnumerable<Manufactyre> ProductTypeList { get; set; }
    }
}
