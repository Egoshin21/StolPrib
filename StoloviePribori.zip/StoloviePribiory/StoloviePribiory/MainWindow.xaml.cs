﻿using StoloviePribiory.Classes;
using StoloviePribiory.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StoloviePribiory
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private IEnumerable<Product> _ProductList;
        public List<Manufactyre> ManufactyreList { get; set; }
        public IEnumerable<Product> ProductList {
            get
            {
                var Result = _ProductList;

                if (SearchFilter != "")
                    Result = Result.Where(
                        p => p.ProductCost.ToString().IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0 ||
                            p.ProductDescription.IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                p.ProductManufacturer.IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                p.ProductName.IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0
                    );

                if (ProductTypeFilterId > 0)
                    Result = Result.Where(
                        p => p.ManufacturerID == ProductTypeFilterId);

                switch (SortType)
                {
                    // сортировка по названию продукции
                    case 1:
                        Result = Result.OrderBy(p => p.ProductCost);
                        break;
                    case 2:
                        Result = Result.OrderByDescending(p => p.ProductCost);
                        break;
                        // остальные сортировки реализуйте сами
                }
                return Result;
            }
            set
            {
                _ProductList = value;
                Invalidate();
            }
        }


        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;

            Globals.DataPrivider = new MySQLDataProvider();
            ProductList = Globals.DataPrivider.GetProducts();

            ManufactyreList = Globals.DataPrivider.GetManufactyres().ToList();
            ManufactyreList.Insert(0, new Manufactyre { Title = "Все типы" });
        }

        public string[] SortList { get; set; } = {
            "Без сортировки",
            "цена по убыванию",
            "цена по возрастанию" 
        };

        private int SortType = 0;

        public event PropertyChangedEventHandler PropertyChanged;

        private void SortTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortType = SortTypeComboBox.SelectedIndex;
            Invalidate();
        }

        private void Invalidate()
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("ProductList"));
        }

        private int ProductTypeFilterId = 0;

        private void ProductTypeFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // запоминаем ID выбранного типа
            ProductTypeFilterId = (ProductTypeFilter.SelectedItem as Manufactyre).ID;
            Invalidate();
        }

        private string SearchFilter = "";
        private void SearchFilterTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            SearchFilter = SearchFilterTextBox.Text;
            Invalidate();
        }

    }
}
